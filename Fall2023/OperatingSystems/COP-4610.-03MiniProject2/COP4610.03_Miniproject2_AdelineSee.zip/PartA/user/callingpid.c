#include "types.h"
#include "user.h"

int main() {
	printf(1, "PID =%d\n", getpid());
        exit();
}
