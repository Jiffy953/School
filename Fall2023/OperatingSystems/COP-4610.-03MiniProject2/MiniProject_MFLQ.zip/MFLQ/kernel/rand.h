#ifndef _RAND_H_
#define _RAND_H_

int rand(void);

#endif
